/* Performs calculation for rate charges */
(function($, Drupal){
	Drupal.behaviors.webform_ext_booking_calcs = { 
		attach: function (context, settings) {		 
		  $('select', context).change(function(){			 
			 calcCharges($, $('#edit-submitted-number-of-guests'));              			 
		  });
		  $('#recalc_price', context).click(function(){			 
			 calcCharges($, $('#edit-submitted-number-of-guests'));		
             return (false);			 
		  }); 
		} 
	}
})(jQuery, Drupal);


function calcCharges($, obj)
{
	var daily_rate = parseFloat($('#edit-submitted-daily-rate').val());
	var daily_rate_add = parseFloat($('#edit-submitted-daily-rate-add').val());			 
	var num_guests = parseInt($(obj).val());
	var sub_total = daily_rate;
	
	/* Parse Arrival Date */
	var start_date = getArrivalDate($);
	
	/* Parse Arrival Date */
	var end_date = getDepartureDate($);
	
	var diff_ms = end_date.getTime() - start_date.getTime();
	var num_days = (diff_ms/(1000*60*60*24));
	
	sub_total *= num_days;
	if (num_guests > 2){			 
	   sub_total += daily_rate_add * (num_guests - 2) * num_days; 
	}
	if (sub_total < 0){sub_total = 0;}
	var str_sub_total = $.number(sub_total, 2 );
	$('#edit-submitted-sub-total').val(sub_total);
	$('#guest_price').text(str_sub_total);		  
}

function getArrivalDate($)
{
	var y = parseInt($('#edit-submitted-date-of-arrival-year').val());
	var options = $('#edit-submitted-date-of-arrival-month option');
	var m = parseInt(options.index(options.filter(':selected')));
	m -= (m > 0) ? 1 : 0;
	var d = parseInt($('#edit-submitted-date-of-arrival-day').val());	
	/* finally return the new date */	
	return new Date(y,m,d);
}

function getDepartureDate($)
{
   y = parseInt($('#edit-submitted-date-of-departure-year').val());
   options = $('#edit-submitted-date-of-departure-month option');
   m = parseInt(options.index(options.filter(':selected')));
   m -= (m > 0) ? 1 : 0;
   d = parseInt($('#edit-submitted-date-of-departure-day').val());
   /* finally return the new date */
   return new Date(y,m,d);
}