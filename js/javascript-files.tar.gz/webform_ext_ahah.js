/* Performs calculation for rate charges */
(function($, Drupal){
	Drupal.behaviors.detectRoomsChange = { 
		attach: function (context, settings) {		 
		  $('label', context).each(alert('poop'););
		} 
	}
})(jQuery, Drupal);