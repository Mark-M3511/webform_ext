
CHANGELOG
========= 

V1.4.0 (April 26, 2013)
-----------------------

   * Adding support for Openid Connect

